import React, { useState } from 'react';
import { Category, FormData, Subcategory } from '../types/Category';
import CategoryList from './CategoryList';
import CategoryForm from './CategoryForm';
import ConfirmationModal from './ConfirmationModal';
import { ToastContainer } from './Toast';
import { useToast } from '../hooks/useToast';

// Mock data
const initialCategories: Category[] = [
  {
    id: '1',
    name: 'General Knowledge',
    description: 'General knowledge and current affairs questions',
    subcategories: [
      { id: '1-1', name: 'Current Affairs', mcqCount: 45 },
      { id: '1-2', name: 'Pakistan Studies', mcqCount: 83 },
      { id: '1-3', name: 'Geography', mcqCount: 0 },
      { id: '1-4', name: 'Science', mcqCount: 0 }
    ],
    totalMCQs: 128
  },
  {
    id: '2',
    name: 'English',
    description: 'English language and literature',
    subcategories: [
      { id: '2-1', name: 'Grammar', mcqCount: 40 },
      { id: '2-2', name: 'Vocabulary', mcqCount: 27 }
    ],
    totalMCQs: 67
  },
  {
    id: '3',
    name: 'Computer Science',
    description: 'Programming and computer science concepts',
    subcategories: [
      { id: '3-1', name: 'Programming', mcqCount: 50 },
      { id: '3-2', name: 'Networking', mcqCount: 20 },
      { id: '3-3', name: 'Databases', mcqCount: 22 }
    ],
    totalMCQs: 92
  }
];

const CategoryManager: React.FC = () => {
  const [categories, setCategories] = useState<Category[]>(initialCategories);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {}
  });

  const { toasts, addToast, removeToast } = useToast();

  const handleSaveCategory = (formData: FormData) => {
    if (editingCategory) {
      // Update existing category
      setCategories(prev => prev.map(cat => 
        cat.id === editingCategory.id 
          ? { ...cat, name: formData.name, description: formData.description }
          : cat
      ));
      addToast('Category updated successfully', 'success');
      setEditingCategory(null);
    } else {
      // Add new category
      const newCategory: Category = {
        id: Date.now().toString(),
        name: formData.name,
        description: formData.description,
        subcategories: [],
        totalMCQs: 0
      };
      setCategories(prev => [...prev, newCategory]);
      addToast('Category created successfully', 'success');
    }
  };

  const handleDeleteCategory = (categoryId: string) => {
    const category = categories.find(cat => cat.id === categoryId);
    if (category) {
      setConfirmModal({
        isOpen: true,
        title: 'Delete Category',
        message: `Deleting "${category.name}" will also delete all ${category.subcategories.length} subcategories and ${category.totalMCQs} MCQs under it. This action cannot be undone.`,
        onConfirm: () => {
          setCategories(prev => prev.filter(cat => cat.id !== categoryId));
          addToast('Category deleted successfully', 'success');
          setConfirmModal(prev => ({ ...prev, isOpen: false }));
          if (editingCategory?.id === categoryId) {
            setEditingCategory(null);
          }
        }
      });
    }
  };

  const handleDeleteSubcategory = (categoryId: string, subcategoryId: string) => {
    const category = categories.find(cat => cat.id === categoryId);
    const subcategory = category?.subcategories.find(sub => sub.id === subcategoryId);
    
    if (subcategory) {
      setConfirmModal({
        isOpen: true,
        title: 'Delete Subcategory',
        message: `Deleting "${subcategory.name}" will also delete ${subcategory.mcqCount} MCQs under it. This action cannot be undone.`,
        onConfirm: () => {
          setCategories(prev => prev.map(cat => 
            cat.id === categoryId 
              ? {
                  ...cat,
                  subcategories: cat.subcategories.filter(sub => sub.id !== subcategoryId),
                  totalMCQs: cat.totalMCQs - (subcategory.mcqCount || 0)
                }
              : cat
          ));
          addToast('Subcategory deleted successfully', 'success');
          setConfirmModal(prev => ({ ...prev, isOpen: false }));
        }
      });
    }
  };

  const handleAddSubcategory = (categoryId: string, name: string) => {
    const newSubcategory: Subcategory = {
      id: `${categoryId}-${Date.now()}`,
      name,
      mcqCount: 0
    };

    setCategories(prev => prev.map(cat => 
      cat.id === categoryId 
        ? {
            ...cat,
            subcategories: [...cat.subcategories, newSubcategory]
          }
        : cat
    ));
    addToast('Subcategory added successfully', 'success');
  };

  const handleEditSubcategory = (categoryId: string, subcategoryId: string, name: string) => {
    setCategories(prev => prev.map(cat => 
      cat.id === categoryId 
        ? {
            ...cat,
            subcategories: cat.subcategories.map(sub =>
              sub.id === subcategoryId ? { ...sub, name } : sub
            )
          }
        : cat
    ));
    addToast('Subcategory updated successfully', 'success');
  };

  const closeModal = () => {
    setConfirmModal(prev => ({ ...prev, isOpen: false }));
  };

  const handleCancelEdit = () => {
    setEditingCategory(null);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <h1 className="text-2xl font-bold text-gray-900">Manage Categories</h1>
          <p className="mt-2 text-gray-600">Add, edit, or organize categories and subcategories. Track total MCQs in each.</p>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
          {/* Category List - Left Side (60%) */}
          <div className="lg:col-span-3">
            <CategoryList
              categories={categories}
              onEditCategory={setEditingCategory}
              onDeleteCategory={handleDeleteCategory}
              onDeleteSubcategory={handleDeleteSubcategory}
              onAddSubcategory={handleAddSubcategory}
              onEditSubcategory={handleEditSubcategory}
            />
          </div>

          {/* Category Form - Right Side (40%) */}
          <div className="lg:col-span-2">
            <CategoryForm
              editingCategory={editingCategory}
              onSave={handleSaveCategory}
              onCancel={handleCancelEdit}
            />
          </div>
        </div>
      </div>

      {/* Confirmation Modal */}
      <ConfirmationModal
        isOpen={confirmModal.isOpen}
        title={confirmModal.title}
        message={confirmModal.message}
        confirmText="Delete"
        cancelText="Cancel"
        onConfirm={confirmModal.onConfirm}
        onCancel={closeModal}
        type="danger"
      />

      {/* Toast Notifications */}
      <ToastContainer toasts={toasts} onRemove={removeToast} />
    </div>
  );
};

export default CategoryManager;