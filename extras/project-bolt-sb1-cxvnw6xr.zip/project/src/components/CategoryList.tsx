import React, { useState } from 'react';
import { Edit, Trash2, Plus, ChevronDown, ChevronRight } from 'lucide-react';
import { Category, Subcategory } from '../types/Category';

interface CategoryListProps {
  categories: Category[];
  onEditCategory: (category: Category) => void;
  onDeleteCategory: (categoryId: string) => void;
  onDeleteSubcategory: (categoryId: string, subcategoryId: string) => void;
  onAddSubcategory: (categoryId: string, name: string) => void;
  onEditSubcategory: (categoryId: string, subcategoryId: string, name: string) => void;
}

const CategoryList: React.FC<CategoryListProps> = ({
  categories,
  onEditCategory,
  onDeleteCategory,
  onDeleteSubcategory,
  onAddSubcategory,
  onEditSubcategory
}) => {
  const [expandedCategories, setExpandedCategories] = useState<Set<string>>(new Set());
  const [addingSubcategory, setAddingSubcategory] = useState<string | null>(null);
  const [editingSubcategory, setEditingSubcategory] = useState<string | null>(null);
  const [subcategoryName, setSubcategoryName] = useState('');
  const [editSubcategoryName, setEditSubcategoryName] = useState('');

  const toggleExpand = (categoryId: string) => {
    const newExpanded = new Set(expandedCategories);
    if (newExpanded.has(categoryId)) {
      newExpanded.delete(categoryId);
    } else {
      newExpanded.add(categoryId);
    }
    setExpandedCategories(newExpanded);
  };

  const handleAddSubcategory = (categoryId: string) => {
    setAddingSubcategory(categoryId);
    setSubcategoryName('');
    if (!expandedCategories.has(categoryId)) {
      toggleExpand(categoryId);
    }
  };

  const saveSubcategory = (categoryId: string) => {
    if (subcategoryName.trim()) {
      onAddSubcategory(categoryId, subcategoryName.trim());
      setAddingSubcategory(null);
      setSubcategoryName('');
    }
  };

  const cancelAddSubcategory = () => {
    setAddingSubcategory(null);
    setSubcategoryName('');
  };

  const startEditSubcategory = (subcategoryId: string, currentName: string) => {
    setEditingSubcategory(subcategoryId);
    setEditSubcategoryName(currentName);
  };

  const saveEditSubcategory = (categoryId: string, subcategoryId: string) => {
    if (editSubcategoryName.trim()) {
      onEditSubcategory(categoryId, subcategoryId, editSubcategoryName.trim());
      setEditingSubcategory(null);
      setEditSubcategoryName('');
    }
  };

  const cancelEditSubcategory = () => {
    setEditingSubcategory(null);
    setEditSubcategoryName('');
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200">
      <div className="px-6 py-4 border-b border-gray-200">
        <h2 className="text-lg font-semibold text-gray-900">Categories & Subcategories</h2>
      </div>
      
      <div className="max-h-96 overflow-y-auto">
        {categories.length === 0 ? (
          <div className="p-8 text-center text-gray-500">
            <p className="text-sm">No categories found. Add your first category to get started.</p>
          </div>
        ) : (
          <div className="divide-y divide-gray-100">
            {categories.map((category, index) => (
              <React.Fragment key={category.id}>
                {/* Category Row */}
                <div className={`p-4 hover:bg-gray-50 transition-colors ${index % 2 === 0 ? 'bg-white' : 'bg-gray-25'}`}>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3 flex-1">
                      <button
                        onClick={() => toggleExpand(category.id)}
                        className="text-gray-400 hover:text-gray-600 transition-colors"
                      >
                        {expandedCategories.has(category.id) ? (
                          <ChevronDown className="w-4 h-4" />
                        ) : (
                          <ChevronRight className="w-4 h-4" />
                        )}
                      </button>
                      
                      <div className="flex-1">
                        <h3 className="font-medium text-gray-900">{category.name}</h3>
                        <div className="flex gap-4 mt-1 text-sm text-gray-500">
                          <span>{category.subcategories.length} Subcategories</span>
                          <span>{category.totalMCQs} MCQs</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => onEditCategory(category)}
                        className="p-1.5 text-blue-600 hover:bg-blue-50 rounded transition-colors"
                        title="Edit Category"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => onDeleteCategory(category.id)}
                        className="p-1.5 text-red-600 hover:bg-red-50 rounded transition-colors"
                        title="Delete Category"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleAddSubcategory(category.id)}
                        className="p-1.5 text-gray-600 hover:bg-gray-100 rounded transition-colors border border-gray-300"
                        title="Add Subcategory"
                      >
                        <Plus className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>

                {/* Expanded Subcategories */}
                {expandedCategories.has(category.id) && (
                  <div className="bg-gray-50">
                    {/* Add Subcategory Form */}
                    {addingSubcategory === category.id && (
                      <div className="px-4 py-3 border-b border-gray-200">
                        <div className="ml-7 flex items-center gap-2">
                          <input
                            type="text"
                            value={subcategoryName}
                            onChange={(e) => setSubcategoryName(e.target.value)}
                            placeholder="Enter subcategory name"
                            className="flex-1 px-3 py-1.5 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') {
                                saveSubcategory(category.id);
                              } else if (e.key === 'Escape') {
                                cancelAddSubcategory();
                              }
                            }}
                            autoFocus
                          />
                          <button
                            onClick={() => saveSubcategory(category.id)}
                            className="px-3 py-1.5 text-sm font-medium text-white bg-blue-600 rounded hover:bg-blue-700 transition-colors"
                          >
                            Save
                          </button>
                          <button
                            onClick={cancelAddSubcategory}
                            className="px-3 py-1.5 text-sm font-medium text-gray-600 bg-gray-100 rounded hover:bg-gray-200 transition-colors"
                          >
                            Cancel
                          </button>
                        </div>
                      </div>
                    )}

                    {/* Subcategories List */}
                    {category.subcategories.map((subcategory) => (
                      <div key={subcategory.id} className="px-4 py-3 border-b border-gray-200 last:border-b-0">
                        <div className="ml-7 flex items-center justify-between">
                          {editingSubcategory === subcategory.id ? (
                            <div className="flex items-center gap-2 flex-1">
                              <input
                                type="text"
                                value={editSubcategoryName}
                                onChange={(e) => setEditSubcategoryName(e.target.value)}
                                className="flex-1 px-3 py-1.5 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                onKeyDown={(e) => {
                                  if (e.key === 'Enter') {
                                    saveEditSubcategory(category.id, subcategory.id);
                                  } else if (e.key === 'Escape') {
                                    cancelEditSubcategory();
                                  }
                                }}
                                autoFocus
                              />
                              <button
                                onClick={() => saveEditSubcategory(category.id, subcategory.id)}
                                className="px-3 py-1.5 text-sm font-medium text-white bg-blue-600 rounded hover:bg-blue-700 transition-colors"
                              >
                                Save
                              </button>
                              <button
                                onClick={cancelEditSubcategory}
                                className="px-3 py-1.5 text-sm font-medium text-gray-600 bg-gray-100 rounded hover:bg-gray-200 transition-colors"
                              >
                                Cancel
                              </button>
                            </div>
                          ) : (
                            <>
                              <div className="flex-1">
                                <span className="text-gray-800 font-medium">{subcategory.name}</span>
                                <span className="ml-3 text-sm text-gray-500">({subcategory.mcqCount} MCQs)</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <button
                                  onClick={() => startEditSubcategory(subcategory.id, subcategory.name)}
                                  className="p-1 text-blue-600 hover:bg-blue-50 rounded transition-colors"
                                  title="Edit Subcategory"
                                >
                                  <Edit className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  onClick={() => onDeleteSubcategory(category.id, subcategory.id)}
                                  className="p-1 text-red-600 hover:bg-red-50 rounded transition-colors"
                                  title="Delete Subcategory"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </React.Fragment>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default CategoryList;