export interface Subcategory {
  id: string;
  name: string;
  mcqCount: number;
}

export interface Category {
  id: string;
  name: string;
  description?: string;
  subcategories: Subcategory[];
  totalMCQs: number;
  isExpanded?: boolean;
}

export interface FormData {
  name: string;
  description: string;
}

export type ToastType = 'success' | 'error' | 'warning';