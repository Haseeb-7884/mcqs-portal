import React from 'react';
import CategoryManager from './components/CategoryManager';

function App() {
  return <CategoryManager />;
}

export default App;