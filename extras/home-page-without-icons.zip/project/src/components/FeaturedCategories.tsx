import React from 'react';
import { ArrowRight } from 'lucide-react';

const categories = [
  {
    name: 'General Knowledge',
    count: 1200,
    color: 'bg-gradient-to-br from-purple-500 to-purple-600',
    textColor: 'text-purple-600',
    bgLight: 'bg-purple-50',
    description: 'Test your general awareness',
    initial: 'GK'
  },
  {
    name: 'English',
    count: 800,
    color: 'bg-gradient-to-br from-green-500 to-green-600',
    textColor: 'text-green-600',
    bgLight: 'bg-green-50',
    description: 'Grammar, vocabulary & comprehension',
    initial: 'EN'
  },
  {
    name: 'Computer Science',
    count: 950,
    color: 'bg-gradient-to-br from-blue-500 to-blue-600',
    textColor: 'text-blue-600',
    bgLight: 'bg-blue-50',
    description: 'Programming, algorithms & theory',
    initial: 'CS'
  },
  {
    name: 'Current Affairs',
    count: 700,
    color: 'bg-gradient-to-br from-red-500 to-red-600',
    textColor: 'text-red-600',
    bgLight: 'bg-red-50',
    description: 'Latest news and events',
    initial: 'CA'
  }
];

const FeaturedCategories: React.FC = () => {
  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Popular Categories</h2>
          <p className="text-xl text-gray-600">Choose from our most practiced subjects</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {categories.map((category) => (
            <div
              key={category.name}
              className={`${category.bgLight} border border-gray-100 rounded-2xl p-6 hover:shadow-lg transition-all duration-300 hover:-translate-y-1 cursor-pointer group relative overflow-hidden`}
            >
              {/* Background Pattern */}
              <div className="absolute top-0 right-0 w-20 h-20 opacity-10">
                <div className={`${category.color} w-full h-full rounded-full transform translate-x-6 -translate-y-6`}></div>
              </div>
              
              {/* Category Initial/Badge */}
              <div className={`${category.color} w-12 h-12 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform shadow-lg`}>
                <span className="text-white font-bold text-sm">{category.initial}</span>
              </div>
              
              <h3 className="text-xl font-semibold text-gray-900 mb-2">{category.name}</h3>
              <p className="text-gray-600 mb-4">{category.description}</p>
              
              <div className="flex items-center justify-between">
                <div className="flex flex-col">
                  <span className="text-2xl font-bold text-gray-900">{category.count.toLocaleString()}</span>
                  <span className="text-sm text-gray-500">MCQs Available</span>
                </div>
                <button className={`flex items-center space-x-1 ${category.textColor} hover:opacity-80 font-medium group-hover:translate-x-1 transition-all duration-300 bg-white px-3 py-2 rounded-lg shadow-sm`}>
                  <span>Explore</span>
                  <ArrowRight className="h-4 w-4" />
                </button>
              </div>
              
              {/* Progress indicator */}
              <div className="mt-4 w-full bg-gray-200 rounded-full h-1">
                <div 
                  className={`${category.color} h-1 rounded-full transition-all duration-500 group-hover:w-full`}
                  style={{ width: '60%' }}
                ></div>
              </div>
            </div>
          ))}
        </div>

        {/* View All Categories Button */}
        <div className="text-center mt-12">
          <button className="bg-gray-100 hover:bg-gray-200 text-gray-700 px-8 py-3 rounded-xl font-semibold transition-all duration-300 hover:scale-105 border border-gray-200">
            View All Categories
          </button>
        </div>
      </div>
    </section>
  );
};

export default FeaturedCategories;