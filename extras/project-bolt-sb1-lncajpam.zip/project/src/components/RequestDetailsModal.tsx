import React from 'react';
import { X, Check, User, Mail, Calendar, FileText, ArrowRight } from 'lucide-react';
import { StatusBadge } from './StatusBadge';
import { UserAvatar } from './UserAvatar';
import type { EditorRequest } from '../types';

interface RequestDetailsModalProps {
  request: EditorRequest | null;
  isOpen: boolean;
  onClose: () => void;
  onAction: (id: string, action: 'approve' | 'decline') => void;
}

export const RequestDetailsModal: React.FC<RequestDetailsModalProps> = ({
  request,
  isOpen,
  onClose,
  onAction
}) => {
  if (!isOpen || !request) return null;

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      weekday: 'long',
      month: 'long',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900">Request Details</h2>
          <button
            onClick={onClose}
            className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-md transition-colors duration-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* User Info */}
          <div className="flex items-center gap-4">
            <UserAvatar name={request.userName} size="lg" />
            <div className="flex-1">
              <h3 className="text-lg font-semibold text-gray-900">{request.userName}</h3>
              <div className="flex items-center gap-2 text-gray-600">
                <Mail className="w-4 h-4" />
                <span>{request.email}</span>
              </div>
              <div className="text-sm text-gray-500 mt-1">User ID: {request.userId}</div>
            </div>
            <StatusBadge status={request.status} />
          </div>

          {/* Role Change Info */}
          <div className="bg-gray-50 rounded-lg p-4">
            <h4 className="font-medium text-gray-900 mb-3">Role Change Request</h4>
            <div className="flex items-center justify-between">
              <div className="text-center">
                <div className="text-sm text-gray-500 mb-1">Current Role</div>
                <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-gray-100 text-gray-700">
                  <User className="w-4 h-4 mr-1" />
                  User
                </span>
              </div>
              <ArrowRight className="w-5 h-5 text-gray-400" />
              <div className="text-center">
                <div className="text-sm text-gray-500 mb-1">Requested Role</div>
                <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-blue-100 text-blue-700">
                  <FileText className="w-4 h-4 mr-1" />
                  Editor
                </span>
              </div>
            </div>
          </div>

          {/* Request Info */}
          <div>
            <div className="flex items-center gap-2 text-gray-600 mb-3">
              <Calendar className="w-4 h-4" />
              <span className="text-sm">Requested on {formatDate(request.dateRequested)}</span>
            </div>

            {request.reason && (
              <div>
                <h4 className="font-medium text-gray-900 mb-2">Reason for Request</h4>
                <div className="bg-gray-50 rounded-lg p-4 text-gray-700">
                  {request.reason}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Actions */}
        <div className="flex flex-col sm:flex-row gap-3 p-6 bg-gray-50 border-t border-gray-200">
          {request.status === 'pending' ? (
            <>
              <button
                onClick={() => {
                  onAction(request.id, 'approve');
                  onClose();
                }}
                className="flex items-center justify-center gap-2 px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-medium transition-colors duration-200"
              >
                <Check className="w-5 h-5" />
                Approve Request
              </button>
              <button
                onClick={() => {
                  onAction(request.id, 'decline');
                  onClose();
                }}
                className="flex items-center justify-center gap-2 px-6 py-3 bg-red-600 hover:bg-red-700 text-white rounded-lg font-medium transition-colors duration-200"
              >
                <X className="w-5 h-5" />
                Decline Request
              </button>
            </>
          ) : (
            <button
              onClick={() => {}}
              className="flex items-center justify-center gap-2 px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors duration-200"
            >
              Go to Role Change Page
            </button>
          )}
        </div>
      </div>
    </div>
  );
};