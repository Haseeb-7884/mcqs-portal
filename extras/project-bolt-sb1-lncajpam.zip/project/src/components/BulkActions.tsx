import React from 'react';
import { Check, X, Download } from 'lucide-react';

interface BulkActionsProps {
  selectedCount: number;
  onBulkAction: (action: 'approve' | 'decline') => void;
  onExport: () => void;
}

export const BulkActions: React.FC<BulkActionsProps> = ({
  selectedCount,
  onBulkAction,
  onExport
}) => {
  return (
    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center gap-3">
          <span className="text-sm font-medium text-blue-900">
            {selectedCount} request{selectedCount !== 1 ? 's' : ''} selected
          </span>
        </div>
        
        <div className="flex gap-2">
          <button
            onClick={() => onBulkAction('approve')}
            className="flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-md text-sm font-medium transition-colors duration-200"
          >
            <Check className="w-4 h-4" />
            Bulk Approve
          </button>
          <button
            onClick={() => onBulkAction('decline')}
            className="flex items-center gap-2 px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-md text-sm font-medium transition-colors duration-200"
          >
            <X className="w-4 h-4" />
            Bulk Decline
          </button>
          <button
            onClick={onExport}
            className="flex items-center gap-2 px-4 py-2 bg-gray-600 hover:bg-gray-700 text-white rounded-md text-sm font-medium transition-colors duration-200"
          >
            <Download className="w-4 h-4" />
            Export CSV
          </button>
        </div>
      </div>
    </div>
  );
};