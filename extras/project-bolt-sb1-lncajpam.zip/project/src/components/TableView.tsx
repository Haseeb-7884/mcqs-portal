import React from 'react';
import { Eye, Check, X } from 'lucide-react';
import { StatusBadge } from './StatusBadge';
import { UserAvatar } from './UserAvatar';
import type { EditorRequest } from '../types';

interface TableViewProps {
  requests: EditorRequest[];
  selectedRequests: Set<string>;
  onSelectRequest: (id: string, checked: boolean) => void;
  onSelectAll: (checked: boolean) => void;
  onViewDetails: (request: EditorRequest) => void;
  onRequestAction: (id: string, action: 'approve' | 'decline') => void;
}

export const TableView: React.FC<TableViewProps> = ({
  requests,
  selectedRequests,
  onSelectRequest,
  onSelectAll,
  onViewDetails,
  onRequestAction
}) => {
  const pendingRequests = requests.filter(r => r.status === 'pending');
  const allPendingSelected = pendingRequests.length > 0 && 
    pendingRequests.every(r => selectedRequests.has(r.id));

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  return (
    <div className="overflow-hidden">
      {/* Mobile Accordion View */}
      <div className="lg:hidden">
        {requests.map((request) => (
          <div key={request.id} className="border-b border-gray-200 last:border-b-0">
            <div className="p-4 space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  {request.status === 'pending' && (
                    <input
                      type="checkbox"
                      checked={selectedRequests.has(request.id)}
                      onChange={(e) => onSelectRequest(request.id, e.target.checked)}
                      className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
                    />
                  )}
                  <UserAvatar name={request.userName} />
                  <div>
                    <div className="font-medium text-gray-900">{request.userName}</div>
                    <div className="text-sm text-gray-500">{request.email}</div>
                  </div>
                </div>
                <StatusBadge status={request.status} />
              </div>
              
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-gray-500">Date:</span>
                  <div className="font-medium">{formatDate(request.dateRequested)}</div>
                </div>
                <div>
                  <span className="text-gray-500">Requested Role:</span>
                  <div className="font-medium">Editor</div>
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => onViewDetails(request)}
                  className="flex items-center gap-2 px-3 py-2 text-gray-700 hover:bg-gray-50 border border-gray-300 rounded-md text-sm transition-colors duration-200"
                >
                  <Eye className="w-4 h-4" />
                  View
                </button>
                {request.status === 'pending' && (
                  <>
                    <button
                      onClick={() => onRequestAction(request.id, 'approve')}
                      className="flex items-center gap-2 px-3 py-2 text-emerald-700 hover:bg-emerald-50 border border-emerald-300 rounded-md text-sm transition-colors duration-200"
                    >
                      <Check className="w-4 h-4" />
                      Approve
                    </button>
                    <button
                      onClick={() => onRequestAction(request.id, 'decline')}
                      className="flex items-center gap-2 px-3 py-2 text-red-700 hover:bg-red-50 border border-red-300 rounded-md text-sm transition-colors duration-200"
                    >
                      <X className="w-4 h-4" />
                      Decline
                    </button>
                  </>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Desktop Table View */}
      <div className="hidden lg:block overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-4 text-left">
                <input
                  type="checkbox"
                  checked={allPendingSelected}
                  onChange={(e) => onSelectAll(e.target.checked)}
                  className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
                />
              </th>
              <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                User
              </th>
              <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Email
              </th>
              <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Date Requested
              </th>
              <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Current Role
              </th>
              <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Requested Role
              </th>
              <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Status
              </th>
              <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {requests.map((request) => (
              <tr key={request.id} className="hover:bg-gray-50 transition-colors duration-200">
                <td className="px-6 py-4 whitespace-nowrap">
                  {request.status === 'pending' && (
                    <input
                      type="checkbox"
                      checked={selectedRequests.has(request.id)}
                      onChange={(e) => onSelectRequest(request.id, e.target.checked)}
                      className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
                    />
                  )}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center gap-3">
                    <UserAvatar name={request.userName} />
                    <div className="font-medium text-gray-900">{request.userName}</div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-gray-600">
                  {request.email}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-gray-600">
                  {formatDate(request.dateRequested)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-700">
                    User
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-700">
                    Editor
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <StatusBadge status={request.status} />
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onViewDetails(request)}
                      className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-md transition-colors duration-200"
                      title="View Details"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                    {request.status === 'pending' && (
                      <>
                        <button
                          onClick={() => onRequestAction(request.id, 'approve')}
                          className="p-2 text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50 rounded-md transition-colors duration-200"
                          title="Approve Request"
                        >
                          <Check className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => onRequestAction(request.id, 'decline')}
                          className="p-2 text-red-600 hover:text-red-700 hover:bg-red-50 rounded-md transition-colors duration-200"
                          title="Decline Request"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {requests.length === 0 && (
        <div className="text-center py-12">
          <div className="text-gray-400 mb-4">
            <Filter className="w-12 h-12 mx-auto" />
          </div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">No requests found</h3>
          <p className="text-gray-500">No editor requests match your current filters.</p>
        </div>
      )}
    </div>
  );
};