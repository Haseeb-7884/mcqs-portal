import React from 'react';

interface StatusBadgeProps {
  status: 'pending' | 'approved' | 'declined';
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status }) => {
  const styles = {
    pending: 'bg-amber-100 text-amber-800 border border-amber-200',
    approved: 'bg-emerald-100 text-emerald-800 border border-emerald-200',
    declined: 'bg-red-100 text-red-800 border border-red-200'
  };

  const labels = {
    pending: 'Pending',
    approved: 'Approved',
    declined: 'Declined'
  };

  return (
    <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium ${styles[status]}`}>
      {labels[status]}
    </span>
  );
};