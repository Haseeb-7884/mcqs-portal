import React from 'react';
import { X, Shield, Users, CheckCircle, AlertTriangle, BookOpen } from 'lucide-react';

interface HelpPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

export const HelpPanel: React.FC<HelpPanelProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <>
      {/* Overlay */}
      <div 
        className="fixed inset-0 bg-black bg-opacity-30 z-40 transition-opacity duration-300"
        onClick={onClose}
      />

      {/* Panel */}
      <div className="fixed right-0 top-0 h-full w-full max-w-md bg-white shadow-2xl z-50 transform transition-transform duration-300 overflow-y-auto">
        {/* Header */}
        <div className="bg-blue-600 text-white p-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold">Help & Instructions</h2>
            <button
              onClick={onClose}
              className="p-1 text-blue-100 hover:text-white hover:bg-blue-700 rounded-md transition-colors duration-200"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
          <p className="text-blue-100 text-sm mt-2">
            Guidelines for processing editor requests
          </p>
        </div>

        {/* Content */}
        <div className="p-6 space-y-8">
          {/* Overview */}
          <section>
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 bg-blue-100 rounded-lg">
                <BookOpen className="w-5 h-5 text-blue-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900">Overview</h3>
            </div>
            <p className="text-gray-600 leading-relaxed">
              Editor requests allow users to request elevated permissions to create, edit, and manage content. 
              As an admin, you review these requests and decide whether to grant editor access.
            </p>
          </section>

          {/* Step-by-step Process */}
          <section>
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 bg-emerald-100 rounded-lg">
                <CheckCircle className="w-5 h-5 text-emerald-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900">Review Process</h3>
            </div>
            <div className="space-y-4">
              <div className="flex gap-3">
                <div className="flex-shrink-0 w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-xs font-semibold">
                  1
                </div>
                <div>
                  <h4 className="font-medium text-gray-900">Review User Profile</h4>
                  <p className="text-sm text-gray-600">Check the user's name, email, and account history.</p>
                </div>
              </div>
              <div className="flex gap-3">
                <div className="flex-shrink-0 w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-xs font-semibold">
                  2
                </div>
                <div>
                  <h4 className="font-medium text-gray-900">Evaluate Request Reason</h4>
                  <p className="text-sm text-gray-600">Read their explanation for why they want editor access.</p>
                </div>
              </div>
              <div className="flex gap-3">
                <div className="flex-shrink-0 w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-xs font-semibold">
                  3
                </div>
                <div>
                  <h4 className="font-medium text-gray-900">Make Decision</h4>
                  <p className="text-sm text-gray-600">Approve or decline based on your assessment.</p>
                </div>
              </div>
            </div>
          </section>

          {/* Security Guidelines */}
          <section>
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 bg-amber-100 rounded-lg">
                <Shield className="w-5 h-5 text-amber-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900">Security Guidelines</h3>
            </div>
            <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
              <div className="flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                <div className="space-y-2 text-sm">
                  <p className="font-medium text-amber-800">Only approve trusted users</p>
                  <ul className="text-amber-700 space-y-1">
                    <li>• Verify the user has a legitimate reason</li>
                    <li>• Check their account activity and history</li>
                    <li>• Consider their experience with the platform</li>
                    <li>• Be cautious with new or inactive accounts</li>
                  </ul>
                </div>
              </div>
            </div>
          </section>

          {/* Role Permissions */}
          <section>
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 bg-purple-100 rounded-lg">
                <Users className="w-5 h-5 text-purple-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900">Editor Permissions</h3>
            </div>
            <div className="space-y-3 text-sm text-gray-600">
              <p>Editors will gain access to:</p>
              <ul className="space-y-2">
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-emerald-500" />
                  Create and edit content
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-emerald-500" />
                  Moderate user submissions
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-emerald-500" />
                  Manage published content
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-emerald-500" />
                  Access editorial tools and features
                </li>
              </ul>
            </div>
          </section>

          {/* Tips */}
          <section>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Tips</h3>
            <div className="bg-blue-50 rounded-lg p-4 text-sm text-blue-800">
              <ul className="space-y-2">
                <li>• Use bulk actions for processing multiple requests efficiently</li>
                <li>• Filter by status to focus on pending requests</li>
                <li>• Use the search function to quickly find specific users</li>
                <li>• Always provide feedback when declining requests</li>
              </ul>
            </div>
          </section>
        </div>
      </div>
    </>
  );
};