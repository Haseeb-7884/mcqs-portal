import React, { useState, useMemo } from 'react';
import { Header } from './components/Header';
import { SearchFilters } from './components/SearchFilters';
import { TableView } from './components/TableView';
import { CardView } from './components/CardView';
import { BulkActions } from './components/BulkActions';
import { RequestDetailsModal } from './components/RequestDetailsModal';
import { HelpPanel } from './components/HelpPanel';
import { mockRequests } from './data/mockData';
import type { EditorRequest, ViewMode, RequestStatus, FilterState } from './types';

function App() {
  const [viewMode, setViewMode] = useState<ViewMode>('table');
  const [selectedRequests, setSelectedRequests] = useState<Set<string>>(new Set());
  const [selectedRequest, setSelectedRequest] = useState<EditorRequest | null>(null);
  const [isHelpOpen, setIsHelpOpen] = useState(false);
  const [requests, setRequests] = useState<EditorRequest[]>(mockRequests);
  const [filters, setFilters] = useState<FilterState>({
    search: '',
    status: 'all',
    dateFrom: '',
    dateTo: ''
  });

  const filteredRequests = useMemo(() => {
    return requests.filter(request => {
      const searchMatch = !filters.search || 
        request.userName.toLowerCase().includes(filters.search.toLowerCase()) ||
        request.email.toLowerCase().includes(filters.search.toLowerCase()) ||
        request.userId.toLowerCase().includes(filters.search.toLowerCase());

      const statusMatch = filters.status === 'all' || request.status === filters.status;

      const dateMatch = (!filters.dateFrom || new Date(request.dateRequested) >= new Date(filters.dateFrom)) &&
        (!filters.dateTo || new Date(request.dateRequested) <= new Date(filters.dateTo));

      return searchMatch && statusMatch && dateMatch;
    });
  }, [requests, filters]);

  const handleRequestAction = (requestId: string, action: 'approve' | 'decline') => {
    setRequests(prev => prev.map(request => 
      request.id === requestId 
        ? { ...request, status: action === 'approve' ? 'approved' : 'declined' }
        : request
    ));
    setSelectedRequests(prev => {
      const newSet = new Set(prev);
      newSet.delete(requestId);
      return newSet;
    });
  };

  const handleBulkAction = (action: 'approve' | 'decline') => {
    const selectedIds = Array.from(selectedRequests);
    setRequests(prev => prev.map(request => 
      selectedIds.includes(request.id) 
        ? { ...request, status: action === 'approve' ? 'approved' : 'declined' }
        : request
    ));
    setSelectedRequests(new Set());
  };

  const handleSelectRequest = (requestId: string, checked: boolean) => {
    setSelectedRequests(prev => {
      const newSet = new Set(prev);
      if (checked) {
        newSet.add(requestId);
      } else {
        newSet.delete(requestId);
      }
      return newSet;
    });
  };

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      const pendingIds = filteredRequests
        .filter(r => r.status === 'pending')
        .map(r => r.id);
      setSelectedRequests(new Set(pendingIds));
    } else {
      setSelectedRequests(new Set());
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <Header 
          viewMode={viewMode}
          onViewModeChange={setViewMode}
        />
        
        <SearchFilters 
          filters={filters}
          onFiltersChange={setFilters}
        />

        {selectedRequests.size > 0 && (
          <BulkActions 
            selectedCount={selectedRequests.size}
            onBulkAction={handleBulkAction}
            onExport={() => {}}
          />
        )}

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
          {viewMode === 'table' ? (
            <TableView 
              requests={filteredRequests}
              selectedRequests={selectedRequests}
              onSelectRequest={handleSelectRequest}
              onSelectAll={handleSelectAll}
              onViewDetails={setSelectedRequest}
              onRequestAction={handleRequestAction}
            />
          ) : (
            <CardView 
              requests={filteredRequests}
              selectedRequests={selectedRequests}
              onSelectRequest={handleSelectRequest}
              onViewDetails={setSelectedRequest}
              onRequestAction={handleRequestAction}
            />
          )}
        </div>

        <RequestDetailsModal 
          request={selectedRequest}
          isOpen={!!selectedRequest}
          onClose={() => setSelectedRequest(null)}
          onAction={handleRequestAction}
        />

        <HelpPanel 
          isOpen={isHelpOpen}
          onClose={() => setIsHelpOpen(false)}
        />

        {/* Floating Help Button */}
        <button
          onClick={() => setIsHelpOpen(true)}
          className="fixed bottom-6 right-6 bg-blue-600 hover:bg-blue-700 text-white p-4 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 z-40 group"
          aria-label="Help"
        >
          <svg className="w-6 h-6 transition-transform group-hover:scale-110" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
        </button>
      </div>
    </div>
  );
}

export default App;