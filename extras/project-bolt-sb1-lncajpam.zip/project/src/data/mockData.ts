import type { EditorRequest } from '../types';

export const mockRequests: EditorRequest[] = [
  {
    id: 'req-001',
    userId: 'user-001',
    userName: 'Sarah Chen',
    email: 'sarah.chen@example.com',
    currentRole: 'user',
    requestedRole: 'editor',
    status: 'pending',
    dateRequested: '2024-01-15T10:30:00Z',
    reason: 'I have 5 years of experience in content creation and would like to contribute to the editorial process.'
  },
  {
    id: 'req-002',
    userId: 'user-002',
    userName: 'Michael Rodriguez',
    email: 'm.rodriguez@example.com',
    currentRole: 'user',
    requestedRole: 'editor',
    status: 'approved',
    dateRequested: '2024-01-14T14:15:00Z',
    reason: 'Former journalism background with expertise in technical writing.'
  },
  {
    id: 'req-003',
    userId: 'user-003',
    userName: 'Emily Johnson',
    email: 'emily.j@example.com',
    currentRole: 'user',
    requestedRole: 'editor',
    status: 'pending',
    dateRequested: '2024-01-16T09:45:00Z',
    reason: 'I\'ve been an active contributor for the past year and understand the platform well.'
  },
  {
    id: 'req-004',
    userId: 'user-004',
    userName: 'David Kim',
    email: 'david.kim@example.com',
    currentRole: 'user',
    requestedRole: 'editor',
    status: 'declined',
    dateRequested: '2024-01-12T16:20:00Z',
    reason: 'Interested in helping with content moderation and quality control.'
  },
  {
    id: 'req-005',
    userId: 'user-005',
    userName: 'Alexandra Smith',
    email: 'alex.smith@example.com',
    currentRole: 'user',
    requestedRole: 'editor',
    status: 'pending',
    dateRequested: '2024-01-17T11:00:00Z',
    reason: 'PhD in English Literature with extensive editing experience in academic publishing.'
  },
  {
    id: 'req-006',
    userId: 'user-006',
    userName: 'James Wilson',
    email: 'james.w@example.com',
    currentRole: 'user',
    requestedRole: 'editor',
    status: 'approved',
    dateRequested: '2024-01-13T13:30:00Z',
    reason: 'Professional editor with 8 years of experience in digital media.'
  }
];