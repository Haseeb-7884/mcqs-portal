export interface EditorRequest {
  id: string;
  userId: string;
  userName: string;
  email: string;
  currentRole: 'user';
  requestedRole: 'editor';
  status: 'pending' | 'approved' | 'declined';
  dateRequested: string;
  reason?: string;
}

export type ViewMode = 'table' | 'card';
export type RequestStatus = 'all' | 'pending' | 'approved' | 'declined';

export interface FilterState {
  search: string;
  status: RequestStatus;
  dateFrom: string;
  dateTo: string;
}