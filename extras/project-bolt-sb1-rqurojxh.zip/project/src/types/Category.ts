export interface Subcategory {
  id: string;
  name: string;
  mcqCount: number;
}

export interface Category {
  id: string;
  name: string;
  description?: string;
  subcategories: Subcategory[];
  totalMCQs: number;
}