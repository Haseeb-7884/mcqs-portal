import React, { useState } from 'react';
import { CategoryTable } from './components/CategoryTable';
import { CategoryForm } from './components/CategoryForm';
import { DeleteModal } from './components/DeleteModal';
import { Toast } from './components/Toast';
import { Category, Subcategory } from './types/Category';
import { mockCategories } from './data/mockData';

function App() {
  const [categories, setCategories] = useState<Category[]>(mockCategories);
  const [expandedCategories, setExpandedCategories] = useState<Set<string>>(new Set());
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [deleteModal, setDeleteModal] = useState<{
    isOpen: boolean;
    type: 'category' | 'subcategory';
    item: Category | Subcategory | null;
    categoryId?: string;
  }>({
    isOpen: false,
    type: 'category',
    item: null
  });
  const [toast, setToast] = useState<{
    isVisible: boolean;
    message: string;
    type: 'success' | 'error';
  }>({
    isVisible: false,
    message: '',
    type: 'success'
  });
  const [addingSubcategoryTo, setAddingSubcategoryTo] = useState<string | null>(null);

  const showToast = (message: string, type: 'success' | 'error') => {
    setToast({ isVisible: true, message, type });
    setTimeout(() => setToast(prev => ({ ...prev, isVisible: false })), 3000);
  };

  const handleSaveCategory = (categoryData: Omit<Category, 'id'>) => {
    if (editingCategory) {
      // Edit existing category
      setCategories(prev => prev.map(cat => 
        cat.id === editingCategory.id 
          ? { ...cat, ...categoryData }
          : cat
      ));
      showToast('Category updated successfully', 'success');
      setEditingCategory(null);
    } else {
      // Add new category
      const newCategory: Category = {
        id: `cat_${Date.now()}`,
        ...categoryData,
        subcategories: [],
        totalMCQs: 0
      };
      setCategories(prev => [...prev, newCategory]);
      showToast('Category added successfully', 'success');
    }
  };

  const handleEditCategory = (category: Category) => {
    setEditingCategory(category);
  };

  const handleDeleteCategory = (category: Category) => {
    setDeleteModal({
      isOpen: true,
      type: 'category',
      item: category
    });
  };

  const handleDeleteSubcategory = (subcategory: Subcategory, categoryId: string) => {
    setDeleteModal({
      isOpen: true,
      type: 'subcategory',
      item: subcategory,
      categoryId
    });
  };

  const confirmDelete = () => {
    if (deleteModal.type === 'category' && deleteModal.item) {
      setCategories(prev => prev.filter(cat => cat.id !== deleteModal.item!.id));
      showToast('Category deleted successfully', 'success');
    } else if (deleteModal.type === 'subcategory' && deleteModal.item && deleteModal.categoryId) {
      setCategories(prev => prev.map(cat => {
        if (cat.id === deleteModal.categoryId) {
          const updatedSubcategories = cat.subcategories.filter(sub => sub.id !== deleteModal.item!.id);
          return {
            ...cat,
            subcategories: updatedSubcategories,
            totalMCQs: cat.totalMCQs - (deleteModal.item as Subcategory).mcqCount
          };
        }
        return cat;
      }));
      showToast('Subcategory deleted successfully', 'success');
    }
    setDeleteModal({ isOpen: false, type: 'category', item: null });
  };

  const handleAddSubcategory = (categoryId: string, subcategoryName: string) => {
    if (!subcategoryName.trim()) {
      showToast('Subcategory name is required', 'error');
      return;
    }

    const newSubcategory: Subcategory = {
      id: `sub_${Date.now()}`,
      name: subcategoryName.trim(),
      mcqCount: 0
    };

    setCategories(prev => prev.map(cat => 
      cat.id === categoryId 
        ? { 
            ...cat, 
            subcategories: [...cat.subcategories, newSubcategory]
          }
        : cat
    ));

    setAddingSubcategoryTo(null);
    showToast('Subcategory added successfully', 'success');
  };

  const toggleCategoryExpansion = (categoryId: string) => {
    setExpandedCategories(prev => {
      const newSet = new Set(prev);
      if (newSet.has(categoryId)) {
        newSet.delete(categoryId);
      } else {
        newSet.add(categoryId);
      }
      return newSet;
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-8">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Manage Categories</h1>
          <p className="text-gray-600">Add, edit, or organize categories and subcategories. Track total MCQs in each.</p>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Left side - Category List */}
          <div className="lg:w-3/5">
            <CategoryTable
              categories={categories}
              expandedCategories={expandedCategories}
              addingSubcategoryTo={addingSubcategoryTo}
              onToggleExpansion={toggleCategoryExpansion}
              onEditCategory={handleEditCategory}
              onDeleteCategory={handleDeleteCategory}
              onDeleteSubcategory={handleDeleteSubcategory}
              onStartAddingSubcategory={setAddingSubcategoryTo}
              onAddSubcategory={handleAddSubcategory}
              onCancelAddingSubcategory={() => setAddingSubcategoryTo(null)}
            />
          </div>

          {/* Right side - Category Form */}
          <div className="lg:w-2/5">
            <CategoryForm
              editingCategory={editingCategory}
              onSave={handleSaveCategory}
              onCancel={() => setEditingCategory(null)}
            />
          </div>
        </div>
      </div>

      {/* Delete Modal */}
      <DeleteModal
        isOpen={deleteModal.isOpen}
        type={deleteModal.type}
        item={deleteModal.item}
        onConfirm={confirmDelete}
        onCancel={() => setDeleteModal({ isOpen: false, type: 'category', item: null })}
      />

      {/* Toast */}
      <Toast
        isVisible={toast.isVisible}
        message={toast.message}
        type={toast.type}
      />
    </div>
  );
}

export default App;