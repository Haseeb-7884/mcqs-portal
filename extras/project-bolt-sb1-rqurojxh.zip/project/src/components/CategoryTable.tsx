import React, { useState } from 'react';
import { ChevronDown, ChevronRight, Edit, Trash2, Plus } from 'lucide-react';
import { Category, Subcategory } from '../types/Category';

interface CategoryTableProps {
  categories: Category[];
  expandedCategories: Set<string>;
  addingSubcategoryTo: string | null;
  onToggleExpansion: (categoryId: string) => void;
  onEditCategory: (category: Category) => void;
  onDeleteCategory: (category: Category) => void;
  onDeleteSubcategory: (subcategory: Subcategory, categoryId: string) => void;
  onStartAddingSubcategory: (categoryId: string) => void;
  onAddSubcategory: (categoryId: string, name: string) => void;
  onCancelAddingSubcategory: () => void;
}

export const CategoryTable: React.FC<CategoryTableProps> = ({
  categories,
  expandedCategories,
  addingSubcategoryTo,
  onToggleExpansion,
  onEditCategory,
  onDeleteCategory,
  onDeleteSubcategory,
  onStartAddingSubcategory,
  onAddSubcategory,
  onCancelAddingSubcategory
}) => {
  const [newSubcategoryName, setNewSubcategoryName] = useState('');

  const handleSaveSubcategory = (categoryId: string) => {
    onAddSubcategory(categoryId, newSubcategoryName);
    setNewSubcategoryName('');
  };

  const handleCancelSubcategory = () => {
    onCancelAddingSubcategory();
    setNewSubcategoryName('');
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
      <div className="px-6 py-4 border-b border-gray-200">
        <h2 className="text-lg font-semibold text-gray-900">Categories & Subcategories</h2>
      </div>
      
      <div className="overflow-auto max-h-96">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Category Name
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Subcategories
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Total MCQs
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {categories.map((category, index) => (
              <React.Fragment key={category.id}>
                {/* Category Row */}
                <tr className={`hover:bg-gray-50 transition-colors ${index % 2 === 0 ? 'bg-white' : 'bg-gray-25'}`}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <button
                        onClick={() => onToggleExpansion(category.id)}
                        className="mr-3 p-1 rounded hover:bg-gray-200 transition-colors"
                      >
                        {expandedCategories.has(category.id) ? (
                          <ChevronDown className="w-4 h-4 text-gray-500" />
                        ) : (
                          <ChevronRight className="w-4 h-4 text-gray-500" />
                        )}
                      </button>
                      <div>
                        <div className="text-sm font-medium text-gray-900">{category.name}</div>
                        {category.description && (
                          <div className="text-sm text-gray-500">{category.description}</div>
                        )}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {category.subcategories.length}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {category.totalMCQs}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <div className="flex space-x-2">
                      <button
                        onClick={() => onEditCategory(category)}
                        className="inline-flex items-center px-3 py-1 rounded-md text-xs font-medium bg-blue-100 text-blue-800 hover:bg-blue-200 transition-colors"
                      >
                        <Edit className="w-3 h-3 mr-1" />
                        Edit
                      </button>
                      <button
                        onClick={() => onDeleteCategory(category)}
                        className="inline-flex items-center px-3 py-1 rounded-md text-xs font-medium bg-red-100 text-red-800 hover:bg-red-200 transition-colors"
                      >
                        <Trash2 className="w-3 h-3 mr-1" />
                        Delete
                      </button>
                      <button
                        onClick={() => onStartAddingSubcategory(category.id)}
                        className="inline-flex items-center px-3 py-1 rounded-md text-xs font-medium border border-gray-300 text-gray-700 hover:bg-gray-50 transition-colors"
                      >
                        <Plus className="w-3 h-3 mr-1" />
                        Add Sub
                      </button>
                    </div>
                  </td>
                </tr>

                {/* Add Subcategory Form (if active) */}
                {addingSubcategoryTo === category.id && (
                  <tr className="bg-blue-50">
                    <td colSpan={4} className="px-12 py-4">
                      <div className="flex items-center space-x-3">
                        <input
                          type="text"
                          value={newSubcategoryName}
                          onChange={(e) => setNewSubcategoryName(e.target.value)}
                          placeholder="Enter subcategory name"
                          className="flex-1 px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                          autoFocus
                        />
                        <button
                          onClick={() => handleSaveSubcategory(category.id)}
                          className="px-3 py-2 bg-blue-600 text-white text-sm rounded-md hover:bg-blue-700 transition-colors"
                        >
                          Save
                        </button>
                        <button
                          onClick={handleCancelSubcategory}
                          className="px-3 py-2 bg-gray-300 text-gray-700 text-sm rounded-md hover:bg-gray-400 transition-colors"
                        >
                          Cancel
                        </button>
                      </div>
                    </td>
                  </tr>
                )}

                {/* Subcategory Rows */}
                {expandedCategories.has(category.id) && category.subcategories.map((subcategory) => (
                  <tr key={subcategory.id} className="bg-gray-25">
                    <td className="px-6 py-3 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="w-7 mr-3"></div> {/* Spacer for alignment */}
                        <div className="border-l-2 border-gray-300 pl-6">
                          <div className="text-sm text-gray-700">↳ {subcategory.name}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-3 whitespace-nowrap text-sm text-gray-500">
                      —
                    </td>
                    <td className="px-6 py-3 whitespace-nowrap text-sm text-gray-700">
                      {subcategory.mcqCount}
                    </td>
                    <td className="px-6 py-3 whitespace-nowrap text-sm font-medium">
                      <div className="flex space-x-2">
                        <button className="inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-blue-100 text-blue-800 hover:bg-blue-200 transition-colors">
                          <Edit className="w-3 h-3 mr-1" />
                          Edit
                        </button>
                        <button
                          onClick={() => onDeleteSubcategory(subcategory, category.id)}
                          className="inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-red-100 text-red-800 hover:bg-red-200 transition-colors"
                        >
                          <Trash2 className="w-3 h-3 mr-1" />
                          Delete
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </React.Fragment>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};