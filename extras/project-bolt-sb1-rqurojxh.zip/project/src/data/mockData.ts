import { Category } from '../types/Category';

export const mockCategories: Category[] = [
  {
    id: 'cat_1',
    name: 'General Knowledge',
    description: 'Broad range of general knowledge topics',
    subcategories: [
      { id: 'sub_1', name: 'Current Affairs', mcqCount: 45 },
      { id: 'sub_2', name: 'Pakistan Studies', mcqCount: 83 },
      { id: 'sub_3', name: 'Geography', mcqCount: 0 },
      { id: 'sub_4', name: 'Science', mcqCount: 0 }
    ],
    totalMCQs: 128
  },
  {
    id: 'cat_2',
    name: 'English',
    description: 'English language and literature',
    subcategories: [
      { id: 'sub_5', name: 'Grammar', mcqCount: 40 },
      { id: 'sub_6', name: 'Vocabulary', mcqCount: 27 }
    ],
    totalMCQs: 67
  },
  {
    id: 'cat_3',
    name: 'Computer Science',
    description: 'Programming and computer science fundamentals',
    subcategories: [
      { id: 'sub_7', name: 'Programming', mcqCount: 50 },
      { id: 'sub_8', name: 'Networking', mcqCount: 20 },
      { id: 'sub_9', name: 'Databases', mcqCount: 22 }
    ],
    totalMCQs: 92
  }
];