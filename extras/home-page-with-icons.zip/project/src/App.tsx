import React from 'react';
import Header from './components/Header';
import HeroSection from './components/HeroSection';
import FeaturedCategories from './components/FeaturedCategories';
import LatestMCQs from './components/LatestMCQs';
import PracticeByTopic from './components/PracticeByTopic';
import CallToAction from './components/CallToAction';
import Highlights from './components/Highlights';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <HeroSection />
      <FeaturedCategories />
      <LatestMCQs />
      <PracticeByTopic />
      <CallToAction />
      <Highlights />
      <Footer />
    </div>
  );
}

export default App;