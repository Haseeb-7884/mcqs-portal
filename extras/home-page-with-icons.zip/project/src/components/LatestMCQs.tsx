import React from 'react';
import { Clock, Tag, ArrowRight } from 'lucide-react';

const mcqs = [
  {
    id: 1,
    question: "Who is the current Secretary-General of the United Nations?",
    category: "Current Affairs",
    timeAgo: "2 hours ago",
    difficulty: "Medium",
    tagColor: "bg-red-100 text-red-700"
  },
  {
    id: 2,
    question: "What is the output of 2+2*2 in programming (following operator precedence)?",
    category: "Computer Science",
    timeAgo: "4 hours ago",
    difficulty: "Easy",
    tagColor: "bg-blue-100 text-blue-700"
  },
  {
    id: 3,
    question: "What is the synonym of 'Obsolete'?",
    category: "English Vocabulary",
    timeAgo: "6 hours ago",
    difficulty: "Medium",
    tagColor: "bg-green-100 text-green-700"
  },
  {
    id: 4,
    question: "Which planet is known as the 'Red Planet'?",
    category: "General Knowledge",
    timeAgo: "8 hours ago",
    difficulty: "Easy",
    tagColor: "bg-purple-100 text-purple-700"
  },
  {
    id: 5,
    question: "What does CPU stand for in computer terminology?",
    category: "Computer Science",
    timeAgo: "12 hours ago",
    difficulty: "Easy",
    tagColor: "bg-blue-100 text-blue-700"
  },
  {
    id: 6,
    question: "In which year did World War II end?",
    category: "History",
    timeAgo: "1 day ago",
    difficulty: "Medium",
    tagColor: "bg-yellow-100 text-yellow-700"
  }
];

const LatestMCQs: React.FC = () => {
  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Latest Uploaded MCQs</h2>
          <p className="text-xl text-gray-600">Fresh questions added by our expert team</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {mcqs.map((mcq) => (
            <div
              key={mcq.id}
              className="bg-white rounded-lg border border-gray-200 p-6 hover:shadow-lg transition-all duration-300 hover:-translate-y-1 cursor-pointer group"
            >
              <div className="flex items-start justify-between mb-4">
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${mcq.tagColor}`}>
                  {mcq.category}
                </span>
                <div className="flex items-center text-gray-500 text-sm">
                  <Clock className="h-4 w-4 mr-1" />
                  {mcq.timeAgo}
                </div>
              </div>

              <h3 className="text-lg font-semibold text-gray-900 mb-3 line-clamp-2 group-hover:text-blue-600 transition-colors">
                {mcq.question}
              </h3>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Tag className="h-4 w-4 text-gray-400" />
                  <span className="text-sm text-gray-500">{mcq.difficulty}</span>
                </div>
                <button className="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-blue-700 transition-colors flex items-center space-x-1 group-hover:translate-x-1 transition-transform">
                  <span>Attempt Now</span>
                  <ArrowRight className="h-3 w-3" />
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <button className="bg-gray-900 text-white px-8 py-3 rounded-lg hover:bg-gray-800 transition-colors font-semibold">
            View All MCQs
          </button>
        </div>
      </div>
    </section>
  );
};

export default LatestMCQs;