import React from 'react';

const topics = [
  'Grammar', 'Programming', 'Current Affairs', 'Pakistan Studies', 'Vocabulary',
  'Mathematics', 'Physics', 'Chemistry', 'Biology', 'History',
  'Geography', 'Economics', 'Political Science', 'Psychology', 'Sociology'
];

const PracticeByTopic: React.FC = () => {
  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Practice by Topic</h2>
          <p className="text-xl text-gray-600">Focus on specific areas to improve your knowledge</p>
        </div>

        <div className="flex flex-wrap gap-3 justify-center">
          {topics.map((topic) => (
            <button
              key={topic}
              className="bg-gray-100 hover:bg-blue-100 text-gray-700 hover:text-blue-700 px-6 py-3 rounded-full font-medium transition-all duration-300 hover:scale-105 border border-transparent hover:border-blue-200"
            >
              {topic}
            </button>
          ))}
        </div>

        <div className="text-center mt-8">
          <p className="text-gray-600 mb-4">Can't find what you're looking for?</p>
          <button className="text-blue-600 hover:text-blue-700 font-semibold underline">
            Request a New Topic
          </button>
        </div>
      </div>
    </section>
  );
};

export default PracticeByTopic;