import React from 'react';
import { Users, BookOpen, Award, Clock, CheckCircle } from 'lucide-react';

const stats = [
  {
    icon: BookOpen,
    number: '10,000+',
    label: 'MCQs Available',
    color: 'text-blue-600'
  },
  {
    icon: Users,
    number: '50,000+',
    label: 'Active Students',
    color: 'text-green-600'
  },
  {
    icon: Award,
    number: '15,000+',
    label: 'Certificates Issued',
    color: 'text-purple-600'
  },
  {
    icon: Clock,
    number: '24/7',
    label: 'Free Access',
    color: 'text-orange-600'
  }
];

const features = [
  'Updated Past Papers',
  'Expert-Curated Questions',
  'Mobile-Friendly Platform',
  'Progress Tracking',
  'Detailed Explanations',
  'Multiple Subjects'
];

const Highlights: React.FC = () => {
  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          {stats.map((stat) => {
            const Icon = stat.icon;
            return (
              <div key={stat.label} className="text-center">
                <Icon className={`h-12 w-12 ${stat.color} mx-auto mb-4`} />
                <div className="text-3xl font-bold text-gray-900 mb-2">{stat.number}</div>
                <div className="text-gray-600">{stat.label}</div>
              </div>
            );
          })}
        </div>

        {/* Features */}
        <div className="bg-white rounded-2xl p-8 shadow-lg">
          <h3 className="text-2xl font-bold text-gray-900 mb-8 text-center">
            Why Choose MCQs Portal?
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature) => (
              <div key={feature} className="flex items-center space-x-3">
                <div className="bg-green-100 rounded-full p-1">
                  <CheckCircle className="h-5 w-5 text-green-600" />
                </div>
                <span className="text-gray-700 font-medium">{feature}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Highlights;