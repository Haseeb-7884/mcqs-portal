import React from 'react';
import { Award, Trophy, CheckCircle } from 'lucide-react';

const CallToAction: React.FC = () => {
  return (
    <section className="py-16 bg-gradient-to-r from-blue-600 to-indigo-700">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center text-white">
          <Trophy className="h-16 w-16 mx-auto mb-6 text-yellow-300" />
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Earn Certificates by Scoring 70% or Above!
          </h2>
          <p className="text-xl mb-8 text-blue-100 max-w-2xl mx-auto">
            Validate your knowledge with our certified assessments. Download and share your achievements with employers and educators.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            <div className="bg-white/10 backdrop-blur rounded-lg p-6">
              <Award className="h-8 w-8 mx-auto mb-3 text-yellow-300" />
              <h3 className="font-semibold mb-2">Verified Certificates</h3>
              <p className="text-blue-100 text-sm">Industry-recognized credentials</p>
            </div>
            <div className="bg-white/10 backdrop-blur rounded-lg p-6">
              <CheckCircle className="h-8 w-8 mx-auto mb-3 text-green-300" />
              <h3 className="font-semibold mb-2">Instant Results</h3>
              <p className="text-blue-100 text-sm">Get your certificate immediately</p>
            </div>
            <div className="bg-white/10 backdrop-blur rounded-lg p-6">
              <Trophy className="h-8 w-8 mx-auto mb-3 text-yellow-300" />
              <h3 className="font-semibold mb-2">Shareable Credentials</h3>
              <p className="text-blue-100 text-sm">Add to LinkedIn & resume</p>
            </div>
          </div>

          <button className="bg-white text-blue-600 px-8 py-4 rounded-xl text-lg font-semibold hover:bg-gray-100 transform hover:scale-105 transition-all duration-300 shadow-lg">
            Start a Test Now
          </button>
        </div>
      </div>
    </section>
  );
};

export default CallToAction;