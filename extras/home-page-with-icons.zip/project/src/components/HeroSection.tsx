import React from 'react';
import { Search, Play } from 'lucide-react';

const HeroSection: React.FC = () => {
  return (
    <section className="bg-gradient-to-br from-blue-50 via-white to-indigo-50 py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
            Master Your Skills with
            <span className="text-blue-600 block mt-2">MCQs Portal</span>
          </h1>
          <p className="text-xl text-gray-600 mb-12 max-w-2xl mx-auto">
            Practice thousands of multiple choice questions, test your knowledge, and earn certificates in various subjects.
          </p>
          
          {/* Search Bar */}
          <div className="max-w-2xl mx-auto mb-8">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
              <input
                type="text"
                placeholder="Search MCQs, Subjects, or Past Papers..."
                className="w-full pl-12 pr-4 py-4 text-lg border border-gray-200 rounded-xl shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300 hover:shadow-md"
              />
            </div>
          </div>

          {/* CTA Button */}
          <button className="bg-blue-600 text-white px-8 py-4 rounded-xl text-lg font-semibold hover:bg-blue-700 transform hover:scale-105 transition-all duration-300 shadow-lg flex items-center space-x-2 mx-auto">
            <Play className="h-5 w-5" />
            <span>Start Practicing Now</span>
          </button>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;